import dnest4.classic as dn4
dn4.postprocess()



# Create the plot as in the document
posterior_sample = dn4.my_loadtxt("posterior_sample.txt") # Load into 2D array
column_stuff = dn4.load_column_names("posterior_sample.txt")
colnames, indices = column_stuff["colnames"], column_stuff["indices"]

import matplotlib.pyplot as plt
plt.hist(posterior_sample[:, indices["d"]], 100)
plt.xlabel("$d$", fontsize=12)
plt.ylabel("Number of posterior samples", fontsize=12)
plt.savefig("post.pdf")
plt.show()

